document.addEventListener('DOMContentLoaded', function(){
  var headerIcon = document.querySelector('header > a');
  if (headerIcon) {
    headerIcon.setAttribute('href', 'https://rokt.com');
  }
});